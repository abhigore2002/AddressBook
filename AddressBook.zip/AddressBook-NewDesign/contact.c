/* Documentation :                                                                                                                                          Name : Suvansh Sharma                                                                                                                                       Date : 15-10-2024                                                                                                                                           Description : An application written in C language. It keeps track of names and telephone/mobile numbers and e-mail addresses. It is a console-based application that uses standard I/O for adding and deleting contact names, phone numbers, and e-mail addresses, searching names and associated numbers and email addresses, updating numbers and email addresses, and deleting contacts.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"


int val_name(char *str) // Function to validation of Name 
{
	int i=0;
	int flag = 1;
	while(str[i]!='\0')
        {                                                                                                                                                                   if((str[i]>='A' && str[i]<='Z') || (str[i]>='a' && str[i]<='z')||(str[i]==' ')) //only uppercase , lowercase and space are allow in name              
		{                                                                                                                                                                   i++;                                                                                                                                                }                                                                                                                                                           else                                                                                                                                                        {                                                                                                                                                              flag = 0;                                                                                                                                                   return flag;                                                                                                                                             }                                                                                                                                                   }
	return flag;
}


int val_phone(char *str) // Function to validation of Phone number
{
	int flag = 1;
        int len = strlen(str);
        if(len!=10)   // Length of the phone number must be 10
        {
                flag =0;
                return flag;
        }
        int j=0;
        while(str[j]!='\0')
        {
                if(str[j]>='0'&& str[j]<='9') // it must contain only 0 to 9 digit
                {
                        j++;
                }
                else
                {
                        flag = 0;
                        return flag;
                }
        }
	return flag;
}

int val_mail(char *str) // Function for validation of email 
{
	 int k=0;
        int flag=1;
        int x=0;
	int count=0;

        while(str[k]!='\0')
        {
                if(str[k]=='@') // It must contain '@'
                {
                        count++;
                        x = k; // strong the index of the '@' for future use
                }
                k++;

        }
        if(count!=1)
        {
                flag = 0;
                return flag; // if '@' is not present or more than 1 time is present then return flag as 0 means invalid email
        }
        else
        {
                while(str[x]!='\0')
                {
			// Check if valid character exists after '@' and valid char before '@'
                        if(str[x+1]>='a' && str[x+1]<='z'&& (str[x-1]>='a' && str[x-1]<='z'))
                        {
                                break;
                        }
                        else
                        {
                                flag = 0;
                                return flag; // If invalid characters, return invalid email
                        }
                }
	char str1[5]=".com";
        int m=0;
	// Check if email ends with ".com"
        for(int i=strlen(str)-4;str[i]!='\0';i++)
        {
                if(str1[m]!=str[i])
                {
                        flag = 0;
                        return flag; // If ".com" is not present, return invalid email
                }
                m++;
        }
        }
	return flag; // Return valid email if checks pass
}

void listContacts(AddressBook *addressBook) // Functioin to list all contacts
{
	// Check if there are any contacts to display
	if(addressBook->contactCount == 0)
	{
		printf("No contacts available.\n");
		return ;
	}

	printf("List of contacts: \n");
	
	// Loop through the contacts and print each contact's details
	for(int i=0;i<addressBook->contactCount;i++)
	{
	printf("%-5dName:%-15sPhone:%-15sEmail:%-15s\n",i+1, addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
	}
}

void initialize(AddressBook *addressBook) {
	addressBook->contactCount = 0;
	//Optionally, load from file if file exists
	// Load contacts from file during initialization (After files)
        loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) {
	saveContactsToFile(addressBook); // Save contacts to file
	exit(EXIT_SUCCESS); // Exit the program
}


void createContact(AddressBook *addressBook) // Function to create the new contact
{
	/* Define the logic to create a Contacts */

	if(addressBook->contactCount >= 100) // it will check is addressbook is full or not
	{
		printf("Address book is full. \n");
		return;
	}

	Contact newContact; // Create a new contact to store the user input

	char name[20];  // Temporary variable to store the name
	printf("Enter name: ");


	scanf(" %[^\n]",name); // Read the name from the user (allowing spaces)

	// Check if the name is valid or not
	int count = val_name(name);
	if(count)
	{
		strcpy(newContact.name,name); // If valid, copy the name into the new contact
	}
	else
	{
		printf("Please Enter the valid Name and Try again!\n");
		return;
	}

	char phone[12]; // Temporary variable to store the phone number
	printf("Enter phone: ");
	scanf("%s",phone); // Read the phone number from the user

	// Check if the phone number is valid or not
	int count1 = val_phone(phone);
	if(count1)
	{
		strcpy(newContact.phone,phone); // If valid, copy the phone number into the new contact
	}
	else
	{
		printf("Please Enter valid phone number\n");
		return;
	}
	
	
	char email[20]; // Temporary variable to store the email
	printf("Enter email: ");
	scanf("%s",email); // Read the email from the user

	// check if the email is valid or not	
	int count2 = val_mail(email);
	if(count2)
	{
		strcpy(newContact.email,email);// If valid, copy the email into the new contact
	}
	else
	{
		printf("Please Enter valid email\n");
		return;
	}
	// Adding the new contact to the address book
	addressBook->contacts[addressBook->contactCount++]=newContact;

	printf("Contact added successfully.\n");
}

void searchContact(AddressBook *addressBook)// Function to search the contact 
{
	if(addressBook->contactCount == 0)
	{
		printf("No contacts available to search.\n"); // Exit if there are no contacts in the address book
		return;
	}
	// Prompt user for search criteria
	printf("Select the choice to search contact base on following option's\n");
	printf("Enter 1 to search Name\n");
	printf("Enter 2 to search phone\n");
	printf("Enter 3 to search email\n");

	int choice;
	scanf("%d",&choice); // Read user's choice

	switch(choice)
	{
		case 1 : // if the user chooses to search by name
			{

				char searchName[50];
				printf("Enter name to search: ");
				scanf(" %[^\n]", searchName);// Read the name to search 

				int flag =0;// flag to track if a contact is found
				int j = 0;
				// Loop through the contacts and compare names
				for(int i=0;i < addressBook->contactCount;i++)
				{
					if(strcasecmp(addressBook->contacts[i].name,searchName)==0)
					{
						flag++;// Increment flag if a match is found
						j=i;
					}
				}
				if(flag==1)
				{
					// Contact found, print its details
printf("Contact found: Name: %-15s Phone:%-15s Email:%-15s\n", addressBook->contacts[j].name,addressBook->contacts[j].phone,addressBook->contacts[j].email);
				}
				else if(flag==0)
				{
					// No contact found with the given name
					printf("Contact not found. \n");
					return;
				}
				else
				{
					// tell user to search base on phone number or email
					printf("Enter 1 to search phone number\n");
					printf("Enter 2 to search email\n");

					int option;
					scanf("%d",&option); // read the choice

					switch(option)
					{
						case 1:
							{	
								char searchphone[10];
								printf("Enter phone number to search :  ");
								scanf(" %[^\n]", searchphone); // read the phone number
								for(int i=0;i<addressBook->contactCount;i++) // search in addressbook
								{
									if(strcasecmp(addressBook->contacts[i].phone,searchphone)==0)
									{
 printf("Contact found: Name: %-15s Phone: %-15s Email: %s\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);

										return;
									}
								}
								printf("Contact not found!\n");
								return;
							}

						case 2:
							{
								char searchemail[20];
								printf("Enter email to search : ");
								scanf(" %[^\n]", searchemail); // Read the email 
								for(int i=0;i<addressBook->contactCount;i++)
								{
									if(strcasecmp(addressBook->contacts[i].email,searchemail)==0) // if email found print the contact details
									{
 printf("Contact found: Name: %-15s Phone: %-15s Email: %s\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
										return;
									}
								}
								printf("Contact not found!\n"); // print this if not found
								return;
							}
						default:
							printf("Invalid input\n"); // if user enter other than 1 and 2 it will be invalid
					}
					case 2 :
					{                                                                                                                                                 	     char searchphone[10];                                                                                                                                       printf("Enter phone number to search :  ");                                                                                                                 scanf(" %[^\n]", searchphone); // Read the phone number to search
						for(int i=0;i<addressBook->contactCount;i++)                                                                                                                {                                                                                                                                                                   if(strcasecmp(addressBook->contacts[i].phone,searchphone)==0) // if found print the details
							{                                                                                                         
printf("Contac found: Name: %-15s Phone: %-15s Email: %s\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);						     return;																			 }										
					}
					printf("Contact not found!\n");
					return;
					}
					case 3 :
					{
						char searchemail[20];
						printf("Enter email to search : ");
						scanf(" %[^\n]", searchemail); // Read the mail from user to search
						for(int i=0;i<addressBook->contactCount;i++)
						{
							if(strcasecmp(addressBook->contacts[i].email,searchemail)==0)// if email found print the details
							{
printf("Contact found: Name: %-15s Phone: %-15s Email:%s\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
								return;
							}
						}
						printf("Contact not found!\n");
						return;
					}
					default :
					printf("Enter the valid choice\n"); // if user enter invalid choice print this prompt
				}
		}
	}
}

void editContact(AddressBook *addressBook) // Function to edit the contact details
{
	printf("Search the contact based on following option \n"); // Prompt message
	printf("Enter 1 to search by Name\n");
	printf("Enter 2 to search by phone\n");
	printf("Enter 3 to search by email\n");

	int choice;
	scanf("%d",&choice); // read the choice

	switch(choice)
	{
		case 1:
			{
				char searchName[50];
				printf("Enter name to search: ");
				scanf(" %[^\n]", searchName);// read the name to search

				int flag =0;
				int j = 0;
				for(int i=0;i < addressBook->contactCount;i++)
				{
					if(strcasecmp(addressBook->contacts[i].name,searchName)==0) // if name found increment the flag
					{
						flag++;
						j=i;
					}
				}
				if(flag==1)
				{
					printf("Contact found: Name: %s,         Phone: %s,              Email: %s\n", 
							addressBook->contacts[j].name,
							addressBook->contacts[j].phone,
							addressBook->contacts[j].email);
					// Display the detail and ask what you want to edit
					printf("What you want to edit :\n");                                                                                                                        printf("Press 1 for Name.\n");                                                                                                                              printf("Press 2 for phone.\n");                                                                                                                             printf("Press 3 for email.\n");                                                                                                                             int option;                                                                                                                                                 scanf("%d",&option); // Read the choice from user
					switch(option)                                                                                                                                              {                                                                                                                                                                   case 1 :                                                                                                                                                    {                                                                                                                                                                   char editname[20];                                                                                                                                          printf("Enter the new Name\n");                                                                                                                             scanf(" %[^\n]",editname); // Read the new name from user
							int flag = val_name(editname); // validate the name by calling val_name()
							if(flag)
							{	
							strcpy(addressBook->contacts[j].name,editname);// copy new name at old name
							printf("Name edited successfully!");
							return;
							}
							else
							{
							printf("Enter the valid name\n"); // display this massage if user enter invalid name
							return;
							}
						}
						case 2 :
						{
							char editphone[12];
							printf("Enter the new phone\n");
							scanf(" %[^\n]",editphone); // read the new phone number
						        //Check if the phone number is valid or not
							int flag = val_phone(editphone);
							if(flag)
							{			
							strcpy(addressBook->contacts[j].phone,editphone); //copy new phone number to the old phone number
							printf("Phone number edited successfully!");
							return;
							}
							else
							{
							printf("Enter the valid phone Number\n");// display this massage if user enter invalid phone number
							}
						}
						case 3 :                                                                                                                                                    {                                                                                                                                                                   char editmail[50];                                                                                                                                          printf("Enter the new email\n");                                                                                                                            scanf(" %[^\n]",editmail);// read the new mail from user
										  																    int flag = val_mail(editmail);// validate the mail by calling val_mail()
							if(flag)
							{																			    strcpy(addressBook->contacts[j].email,editmail); // copy the new mail to the old mail
			 																							    printf("email number edited successfully!");
																										    return;
							}
							else
							{
								printf("Enter the valid Email\n");// display this massage if user enter invalid mail number
								return;
							}
																									    }
						default:
																									    printf("Invalid input\n");
					}
				}
				else if(flag==0)
				{

					printf("Contact not found. \n");
					return;
				}
				else
				{       // display this message if multiple names of same name are present.
					printf("There is having multiple names of this name so search by using phone or email\n");
					printf("Try again!\n");
					return;
				}
			}
		case 2:
			{
				char searchphone[20];
				printf("Enter phone number of the contact to edit: ");
				scanf(" %[^\n]", searchphone); // Read the phone number
				int i;
				int flag=0;
				for (i = 0; i < addressBook->contactCount; i++)
				{
					if (strcasecmp(addressBook->contacts[i].phone, searchphone) == 0)
					{
						flag = 1; // if found make flag 1
						break;
					}
				}
				if(flag=0)
				{

					printf("Invalid Phone number\n"); //contact with this phone number is not present
				}
				else
				{
					printf("Contact found: Name: %s, Phone: %s, Email: %s\n",
							addressBook->contacts[i].name,
							addressBook->contacts[i].phone,
							addressBook->contacts[i].email);

					printf("What you want to edit :\n"); // Ask user what you want to edit and select the option for that
					printf("Press 1 for Name.\n");
					printf("Press 2 for phone.\n");
					printf("Press 3 for email.\n");
					int option;
					scanf("%d",&option);
					switch(option)
					{
						case 1 :
							{
								char editname[20];
								printf("Enter the new Name\n");
								scanf(" %[^\n]",editname); // Read the new name
								int flag = val_name(editname);// validate new name
								if(flag)
								{							
								strcpy(addressBook->contacts[i].name,editname); //copy new name of the old name
								printf("Name edited successfully!");
								return;
								}
								else
								{
								printf("Please Enter the valid Name\n");
								return;
								}
							}
						case 2 :
							{
								char editphone[12];
								printf("Enter the new phone\n");
								scanf(" %[^\n]",editphone); // read the new phone number
								int flag = val_phone(editphone); // validate phone number
								if(flag)
								{
								strcpy(addressBook->contacts[i].phone,editphone); //copy new phone to the old phone number
								printf("Phone number edited successfully!");
								return;
								}
								else
								{
									printf("Please Enter the valid Phone number\n");
								}
							}
						case 3 :
							{
								char editmail[50];
								printf("Enter the new email\n");
								scanf(" %[^\n]",editmail); // Read new mail
								int flag = val_mail(editmail);// validate new mail
								if(flag)
								{
								strcpy(addressBook->contacts[i].email,editmail); // copy new mail to the old mail
								printf("email number edited successfully!");
								return;
								}
								else
								{
								printf("Please Enter the valid email\n");
								return;
								}
							}
						default:
							printf("Please select correct Option!\n");
							printf("Try again!\n"); 
					}
					return;
				}
				case 3:
				{
					char searchemail[20];
					printf("Enter email to search : ");
					scanf(" %[^\n]", searchemail); // read mail to the search
					for(int i=0;i<addressBook->contactCount;i++)
					{
						if(strcasecmp(addressBook->contacts[i].email,searchemail)==0)
						{
 printf("Contact found: Name: %-15s Phone: %-15s Email: %s\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
						//ask user what you want to edit and select option for that
							printf("What you want to edit :\n");
							printf("Press 1 for Name.\n");                                                                                                                              printf("Press 2 for phone.\n");                                                                                                                             printf("Press 3 for email.\n");                                                                                                                             int option;                                                                                                                                                 scanf("%d",&option); // read the choice from user
							switch(option)                                                                                                                                              {                                                                                                                                                                   case 1 :                                                                                                                                                    {                                                                                                                                                                   char editname[20];                                                                                                                                          printf("Enter the new Name\n");                                                                                                                             scanf(" %[^\n]",editname); // read the new name
									int flag = val_name(editname); // validate the new name
									if(flag)
									{	
									strcpy(addressBook->contacts[i].name,editname);// copy the new name to the old name
									printf("Name edited successfully!");         
									return;
									}
							        }
								case 2 :                                                                                                                                                    {                                                                                                                                                                   char editphone[12];                                                                                                                                         printf("Enter the new phone\n"); // read the new phone number
																												    scanf(" %[^\n]",editphone);                                                                                                                                 int flag = val_phone(editphone);// validate phone number
									if(flag)
									{
									strcpy(addressBook->contacts[i].phone,editphone);// copy new to the old
									printf("Phone number edited successfully!");                                                                                                                return;
									}
									else
									{
									printf("Enter the valid phone number\n");
									return;
									}
																											    }
								case 3 :                                                                                                                                                    {                                                                                                                                                                   char editmail[50];                                                                                                                                          printf("Enter the new email\n");                                                                                                                            scanf(" %[^\n]",editmail); // read new mail
												  																    int flag = val_mail(editmail);// validate new mail
									if(flag)
									{	
									strcpy(addressBook->contacts[i].email,editmail);// copy new to the old mail
									printf("email number edited successfully!");                                                                                                                return;                                                                                                                                                     }
									else
									{
									printf("Enter the valid emai\n");
									return;
									}
																											    }
								default:                                                                                                                                                      printf("Invalid input\n");                                                                                                                          }                                                                                                                                                   }

					}

				}
			}
		default:
			printf("Please Enter valid choice\n");
	}
}

void deleteContact(AddressBook *addressBook) // Function to delete contact
{
	if(addressBook->contactCount==0)
	{
		printf("No contacts available to delete\n");
		return;
	}
	// ask user to search contact base on following option to delete that contact
	printf(" search the contact base on following option\n");
	printf("Enter 1 to search by Name\n");
	printf("Enter 2 to search by phone\n");
	printf("Enter 3 to search by email\n");

	int choice;
	scanf("%d",&choice); // read the choice from user

	switch(choice)
	{
		case 1:
			{
				char delete[20];
				printf("Enter the Name which you want to delete\n");
				scanf(" %[^\n]",delete); // read the name
				int flag = 0;
				int j=0;
				for(int i = 0;i<addressBook->contactCount;i++)
				{
					if(strcasecmp(addressBook->contacts[i].name,delete)==0)
					{
						flag++; //increment the flag if contact is found
						j=i;// store the index of contact in other variable for future use
					}
				}

				if(flag==1)
				{
					for(int i=j;i<addressBook->contactCount-1;i++)
					{
						addressBook->contacts[i]=addressBook->contacts[i+1];// shift the contact 
					}

					addressBook->contactCount--; // decrement the contactCount
					printf("Contact deleted successfully!");
					return;
				}
				else if(flag ==0)
				{
					printf("Contact not found!\n");
					return;
				}
				else
				{
					// if more than one contact with same name then search  base on phone or mail 
					printf("There is having more than one contact with same name\n");
											
					printf("Enter 1 to delete contact base on phone number\n");
					printf("Enter 2 to delete contact base on email\n");

					int option ;
					scanf("%d",&option); //Read the choice from user

					switch(option)
					{
						case 1 :
							{
								char phone[12];
								printf("Enter the phone number: ");
								scanf(" %[^\n]",phone); // Read the number to search 
								for(int i=0;i<addressBook->contactCount-1;i++)
								{
									if(strcasecmp(addressBook->contacts[i].phone,phone)==0) // If number is found then delete the contact
									{
										for(int j=i;j<addressBook->contactCount-1;j++)
										{
											addressBook->contacts[j]=addressBook->contacts[j+1];
										}
										addressBook->contactCount--; // decrement the contactCount
										printf("Contact Deleted Successfully!\n");
										return;
									}
								}
								break;
							}
						case 2 :
							{
								char email[50];
								printf("Enter the mail: ");
								scanf(" %[^\n]",email); // Read the mail from user
								for(int i=0;i<addressBook->contactCount-1;i++)
								{
									if(strcasecmp(addressBook->contacts[i].email,email)==0)// If mail is found then delete the contact
									{
										for(int j=i;j<addressBook->contactCount-1;j++)
										{
											addressBook->contacts[j]=addressBook->contacts[j+1];
										}
										addressBook->contactCount--;// decrement the contactCount
										printf("Contact Deleted Successfully!\n");
										return;
									}
								}
								break;
							}

						default:
							printf("Invalid input\n");
							return;

					}
				}
				case 2:
				{
					char phone[12];
					printf("Enter the phone number of the contact to delete: ");
					scanf(" %[^\n]",phone); // Read the phone number from user
					for(int i=0;i<addressBook->contactCount-1;i++)
					{
						if(strcasecmp(addressBook->contacts[i].phone,phone)==0) // If phone number is found then delete the contact
						{
							for(int j=i;j<addressBook->contactCount-1;j++)
							{
								addressBook->contacts[j]=addressBook->contacts[j+1];
							}
							addressBook->contactCount--; // decrement the contactCount by 1
							printf("Contact Deleted Successfully!\n");
							return;
						}
					}
					break;
				}
				case 3:
				{
					char email[50];
					printf("Enter the email of the contact to delete: ");
					scanf(" %[^\n]",email);// Read the mail
					for(int i=0;i<addressBook->contactCount-1;i++)
					{
						if(strcasecmp(addressBook->contacts[i].email,email)==0)// if mail is found then delete the contact 
						{
							for(int j=i;j<addressBook->contactCount-1;j++)
							{
								addressBook->contacts[j]=addressBook->contacts[j+1];
							}
							addressBook->contactCount--; // decrement the contactCount by 1
							printf("Contact Deleted Successfully!\n");
							return;
						}
					}
					break;
				}
				default:
				printf("You entered the wrong choice, Try again!\n");
		}
	}
}
