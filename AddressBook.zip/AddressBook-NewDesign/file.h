#ifndef FILE_H
#define FILE_H

#define FILENAME "contacts.dat" // added this line
#include "contact.h"

void saveContactsToFile(AddressBook *addressBook);
void loadContactsFromFile(AddressBook *addressBook);

#endif
