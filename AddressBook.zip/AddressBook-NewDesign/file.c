#include <stdio.h>
#include "file.h"
#include "contact.h"

// Save contacts to a file

void saveContactsToFile(AddressBook *addressBook) {
    FILE *file = fopen("contact.csv", "w"); // Open file in text mode for writing
    if (file == NULL) {
        printf("Error opening file for saving contacts.\n");
        return;
    }

    //printf("%d\n",addressBook->contactCount);
    fprintf(file, "%d\n",addressBook->contactCount);

    // Writing each contact's details to the file
    for (int i = 0; i < addressBook->contactCount; i++) {
        fprintf(file, "%s, %s, %s\n", addressBook->contacts[i].name,
                addressBook->contacts[i].phone, addressBook->contacts[i].email);
    }

    fclose(file); // Close the file
    printf("Contacts saved successfully!\n");
}

// Load contacts from a file
void loadContactsFromFile(AddressBook *addressBook)
{
	FILE *file = fopen("contact.csv","r");
	if(file==NULL)
	{
		printf("Error opening file for saving contacts.\n");
		return;
	}

	fscanf(file,"%d\n",&addressBook->contactCount);
	for(int i=0;i<addressBook->contactCount;i++)
	{
		fscanf(file,"%[^,],%[^,],%[^\n]\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
	}
	
	fclose(file);

}
